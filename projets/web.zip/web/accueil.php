<html>
<head>
		<title>...</title>
		<meta charset ="utf-8">
		<script type="text/javascript">
		function date_heure(id)
		{
		date = new Date;
        annee = date.getFullYear();
        moi = date.getMonth();
        mois = new Array('Janvier', 'F&eacute;vrier', 'Mars', 'Avril', 'Mai', 'Juin', 'Juillet', 'Ao&ucirc;t', 'Septembre', 'Octobre', 'Novembre', 'D&eacute;cembre');
        j = date.getDate();
        jour = date.getDay();
        jours = new Array('Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi');
        h = date.getHours();
        if(h<10)
        {
                h = "0"+h;
        }
        m = date.getMinutes();
        if(m<10)
        {
                m = "0"+m;
        }
        s = date.getSeconds();
        if(s<10)
        {
                s = "0"+s;
        }
        resultat = 'Nous sommes le '+jours[jour]+' '+j+' '+mois[moi]+' '+annee+' il est '+h+':'+m+':'+s;
        document.getElementById(id).innerHTML = resultat;
        setTimeout('date_heure("'+id+'");','1000');
        return true;
}
</script>
</head>
	<div id="text"></div>		
<body>
<style type ="text/css">

body{bgcolor: white;
color: red;}
#img{width:200px ;
margin-left:1200px;
position:absolute;
top:px;}
.afficher{margin-top:300px;
text-align: right;
top: 100px;
}
h1{ text-align: center;
}
.presentation{
				text-align:center;
				border: 1px blue groove;
				border-left: 2px double blue;
				border-right: 1px  double blue;
				border-width: 2px;
				border-radius:10px;
				box-shadow:6px 6px 6px black;
				text-shadow : 4px 4px 4px black;
				color:blue;
}
#pun{
	margin-left: 1400px;
	margin-bottom: 900px;
	position-absolute;
	top:50px;
	
}
.pied{
background:grey;

position:relative;

bottom:8px;





width:100%;


padding-bottom:150px;

height:400px;

}
#date_heure{
	color:blue;
	position:absolute;
	bottom: 20px;
	left:1050px;
}
.prenom{
	position:absolute;
	top:125px;
	left:140px;
}
.pname{
	position:absolute;
	top:125px;
}
.formulaire{
	position:absolute;
	top:25px;
	left:500px;
}
.name{
	position:absolute;
	top:100px;
}

.nom{
	position:absolute;
	top:100px;
	left:140px;
}
.email{
	position:absolute;
	top:150px;
}
.mail{
	position:absolute;
	top:150px;
	left:180px;
	
}
#message{
	position:absolute;
	top:200px;
	left:130px;
}
#msg{
	position: absolute;
	top:200px;
}
#valider{
	position:absolute;
	top:300px;
	left:50px;
}
#effacer{
	position:absolute;
	top:300px;
	left:100px;
}
.table{
	color:blue;
	background-color:orange;
	text-align:center;
	
	
}
.title{
	position:relative;
	font-size:1.2em;
	margin:20px;
	border:2px blue solid;
	background-color:#FF9833;
	
}
.bas{
	background-color:red;
	}
.aside{

background-image:linear-gradient(blue,purple);
}	
#clean{
	position:relative;
	left :1000px;
	bottom:50px;
}
	

	
	


	
	
</style>
<h1>Bienvenue sur le site de gestion des entreprises en Licence Professionelle</h1>
<p><h2>Présentation du Site</h2><br/>
<br/>
<br/>
<p class="presentation"><b>Ce site permet de consulter les entreprises selon plusieurs criteres,la creation d'un nouveau stage <br />
ou d'une nouvelle alternance pour un etudiant ainsi qu'un tableau de bord sur les missions confiées <br/>
et les outils les plus utilisées sur plusieurs années.</b></p>







<?php
$date= date("d-m-Y");
$heure= date("H:i:s");

if ($heure < 19){
	echo "<body bgcolor='white' >"
									;}
else 
	echo "<body bgcolor ='black'>";
	



?>
<div id ="haut">
<br/>
<hr color="black">
	<p class="afficher"/><?php echo $heure ?>
<hr color="black">	
</div>
<footer class="pied">
	<a target="_blank"href="https://www.univ-poitiers.fr/"/>
	<img src = "./logo.png" alt ="univPotiers" title="Logo" id="img"></a>
	<a target ="_blank" href="http://pun.univ-poitiers.fr/"/>
	<img src ="pun.png"alt ="pun" title ="pun" id="pun"/></a><br/>
	<form method ="post" action ="accueil.php">
	<h2 class="formulaire">Formulaire de contact</h2>
	<label for="prenom"class="pname" >Entrez votre prenom:</label>
	<input type="prenom" placeholder="entrez votre prenom"required size="15"class="prenom"name="prenom"/><br/>
	<label for="nom"class="name">Entrez votre nom:</label>
	<input type="nom" name="nom" placeholder="entrez votre nom" required size="10" class="nom"/><br/>
	<label for="email"class="email">Entrez votre adresse email:</label>
	<input type="email"name="email"placeholder="entrez votre adresse email"required size="20"maxlength="40"class="mail"name="email"/>
	<label for="message"id="msg">Donnez votre avis:</label>
	<textarea id="message" rows="5" cols="33"placeholder="donnez votre avis"required name="message"></textarea>
	<input type ="submit" name ="valider" value="ok"id="valider"/>
	<input type ="reset" name="effacer" value="effacer" id="effacer"/>
	</form>
</footer>
<div class="aside">

<?php
error_reporting(0);
try{
		$bdd = new PDO('mysql:host=localhost;dbname=mcdtrue;charset=utf8','root', '');
}
	catch (Exception $e)	
 {
			// Message d’erreur si problème de connexion
            die('Erreur : ' . $e->getMessage());
          }
	
	
    
	$requete ="insert into commentateurs VALUES('".$_POST['nom']."','".$_POST['prenom']."','".$_POST['email']."','".$_POST['message']."')";
	$resultat = $bdd -> exec($requete);
	
	$requetedeux="Select * from commentateurs";
	
	$resultatdeux = $bdd -> query($requetedeux);
	$ligne = $resultatdeux ->fetch();
	If ($_POST['valider'])
	{
		
		echo "<table border='2' class='table'align ='center'>";
		echo"<caption class='title'>Avis des visiteurs</caption>";
		
		echo"<tr><th>Nom</th><th>Prenom</th><th>Email</th><th>Message</th></tr>";
		While($ligne)
		{	
			echo '<tr><td>'.$ligne["nom"].'</td><td>'.$ligne["prenom"].'</td><td>'.$ligne["email"].'</td><td>'.$ligne["avis"].'</td></tr>';
				$ligne= $resultatdeux ->fetch();
		}
	}
	echo"</table>";
	
	
 $bdd=null;
?>
<input type ="reset" name ="effacer"id="clean" />
<?php
$requetetrois="delect* from commentateurs";

$resultattrois =$bdd->query($requetetrois);



	
		

?>		 
</div>

		  
<body>
<span id="date_heure"></span>
<script type="text/javascript">window.onload = date_heure('date_heure');</script>
</body>
</html> 